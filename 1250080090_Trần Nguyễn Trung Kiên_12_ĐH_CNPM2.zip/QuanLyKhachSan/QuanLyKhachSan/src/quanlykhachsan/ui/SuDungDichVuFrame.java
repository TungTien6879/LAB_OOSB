package quanlykhachsan.ui;

import quanlykhachsan.DataStore;
import quanlykhachsan.model.ChiTietDichVu;
import quanlykhachsan.model.DatPhong;
import quanlykhachsan.model.DichVu;
import quanlykhachsan.util.UiUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class SuDungDichVuFrame extends JFrame {

    private final JComboBox<String> cbPhieu = new JComboBox<>();
    private final JComboBox<String> cbDV = new JComboBox<>();
    private final JSpinner spSL = new JSpinner(new SpinnerNumberModel(1, 1, 999, 1));
    private final JTable table = new JTable(UiUtil.model(new String[]{
            "Dịch vụ", "Đơn vị", "Đơn giá", "Số lượng", "Thành tiền", "Ngày sử dụng"}));
    private final JLabel lbTong = new JLabel();
    private final JLabel lbKhach = new JLabel();

    public SuDungDichVuFrame() {
        super("Sử dụng dịch vụ");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1000, 620);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(new EmptyBorder(12, 12, 12, 12));

        // ----- Thanh chọn phiếu + thêm dịch vụ -----
        JPanel top = new JPanel(new GridBagLayout());
        top.setBorder(BorderFactory.createTitledBorder("Ghi nhận sử dụng dịch vụ"));
        GridBagConstraints f = new GridBagConstraints();
        f.insets = new Insets(4, 6, 4, 6);
        f.anchor = GridBagConstraints.WEST;
        f.gridx = 0;
        f.gridy = 0;
        top.add(new JLabel("Phiếu đang sử dụng:"), f);
        f.gridx = 1;
        f.fill = GridBagConstraints.HORIZONTAL;
        top.add(cbPhieu, f);
        f.gridx = 0;
        f.gridy = 1;
        f.fill = GridBagConstraints.NONE;
        top.add(new JLabel("Dịch vụ:"), f);
        f.gridx = 1;
        f.fill = GridBagConstraints.HORIZONTAL;
        top.add(cbDV, f);
        f.gridx = 2;
        f.fill = GridBagConstraints.NONE;
        top.add(new JLabel("Số lượng:"), f);
        f.gridx = 3;
        top.add(spSL, f);
        JButton btnThem = UiUtil.btn("Thêm dịch vụ");
        f.gridx = 4;
        top.add(btnThem, f);
        f.gridx = 0;
        f.gridy = 2;
        f.gridwidth = 5;
        top.add(lbKhach, f);
        lbKhach.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lbKhach.setForeground(new Color(0x1F3864));

        // ----- Bảng chi tiết -----
        table.setRowHeight(26);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        UiUtil.widths(table, 220, 80, 120, 90, 140, 130);

        JPanel south = new JPanel(new BorderLayout());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnCapNhat = UiUtil.btn("Cập nhật số lượng");
        JButton btnXoa = UiUtil.btn("Xóa mục đã chọn");
        JButton btnLamMoi = UiUtil.btn("Làm mới");
        buttons.add(btnCapNhat);
        buttons.add(btnXoa);
        buttons.add(btnLamMoi);
        lbTong.setFont(new Font("Segoe UI", Font.BOLD, 15));
        JPanel tongPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        tongPanel.add(lbTong);
        south.add(buttons, BorderLayout.WEST);
        south.add(tongPanel, BorderLayout.EAST);

        root.add(top, BorderLayout.NORTH);
        root.add(new JScrollPane(table), BorderLayout.CENTER);
        root.add(south, BorderLayout.SOUTH);
        setContentPane(root);

        refresh();
        cbPhieu.addActionListener(e -> {
            resetChon();
            refreshBang();
        });

        btnThem.addActionListener(e -> {
            DatPhong dp = selectedPhieu();
            DichVu dv = selectedDV();
            if (dp == null || dv == null) return;
            int sl = (Integer) spSL.getValue();
            dp.dichVus.add(new ChiTietDichVu(dv.maDV, sl, LocalDate.now()));
            DataStore.get().save();
            refreshBang();
            UiUtil.msg(this, "Đã ghi nhận " + sl + " " + dv.donVi + " \"" + dv.tenDV + "\" cho phiếu " + dp.maDP + ".");
        });

        btnCapNhat.addActionListener(e -> {
            DatPhong dp = selectedPhieu();
            int idx = table.getSelectedRow();
            if (dp == null || idx < 0) {
                UiUtil.err(this, "Hãy chọn một dòng dịch vụ trong bảng.");
                return;
            }
            DichVu dv = DataStore.get().findDV(dp.dichVus.get(idx).maDV);
            dp.dichVus.get(idx).soLuong = (Integer) spSL.getValue();
            DataStore.get().save();
            refreshBang();
            UiUtil.msg(this, "Đã cập nhật số lượng \"" + (dv == null ? "?" : dv.tenDV) + "\".");
        });

        btnXoa.addActionListener(e -> {
            DatPhong dp = selectedPhieu();
            int idx = table.getSelectedRow();
            if (dp == null || idx < 0) {
                UiUtil.err(this, "Hãy chọn một dòng dịch vụ trong bảng.");
                return;
            }
            if (!UiUtil.confirm(this, "Xóa dòng dịch vụ đã chọn?")) return;
            dp.dichVus.remove(idx);
            DataStore.get().save();
            refreshBang();
        });

        btnLamMoi.addActionListener(e -> {
            resetChon();
            refresh();
        });
    }

    private void resetChon() {
        table.clearSelection();
        spSL.setValue(1);
    }

    private DatPhong selectedPhieu() {
        Object it = cbPhieu.getSelectedItem();
        if (it == null) {
            UiUtil.err(this, "Hiện không có phiếu nào \"Đang sử dụng\". Hãy nhận phòng trước.");
            return null;
        }
        String ma = it.toString().split(" - ")[0].trim();
        return DataStore.get().datPhongs.stream().filter(d -> d.maDP.equals(ma)).findFirst().orElse(null);
    }

    private DichVu selectedDV() {
        Object it = cbDV.getSelectedItem();
        if (it == null) {
            UiUtil.err(this, "Vui lòng chọn dịch vụ.");
            return null;
        }
        String ma = it.toString().split(" - ")[0].trim();
        return DataStore.get().findDV(ma);
    }

    private void refresh() {
        DataStore ds = DataStore.get();

        String selPhieu = null;
        Object itPhieu = cbPhieu.getSelectedItem();
        if (itPhieu != null) selPhieu = itPhieu.toString().split(" - ")[0].trim();

        cbPhieu.removeAllItems();
        List<DatPhong> active = new ArrayList<>();
        for (DatPhong dp : ds.datPhongs)
            if (dp.trangThai.equals(DatPhong.DANG_SU_DUNG)) active.add(dp);
        for (DatPhong dp : active)
            cbPhieu.addItem(dp.maDP + " - " + ds.tenKH(dp.maKH) + " - phòng " + dp.maPhong);
        if (selPhieu != null) {
            for (int i = 0; i < cbPhieu.getItemCount(); i++)
                if (cbPhieu.getItemAt(i).startsWith(selPhieu + " - ")) {
                    cbPhieu.setSelectedIndex(i);
                    break;
                }
        }

        String selDV = null;
        Object itDV = cbDV.getSelectedItem();
        if (itDV != null) selDV = itDV.toString().split(" - ")[0].trim();

        cbDV.removeAllItems();
        for (DichVu dv : ds.dichVus)
            cbDV.addItem(dv.maDV + " - " + dv.tenDV + " (" + UiUtil.money(dv.donGia) + "/" + dv.donVi + ")");
        if (selDV != null) {
            for (int i = 0; i < cbDV.getItemCount(); i++)
                if (cbDV.getItemAt(i).startsWith(selDV + " - ")) {
                    cbDV.setSelectedIndex(i);
                    break;
                }
        }

        refreshBang();
    }

    private void refreshBang() {
        DataStore ds = DataStore.get();
        DatPhong dp = selectedPhieuQuiet();
        List<Object[]> rows = new ArrayList<>();
        if (dp != null) {
            for (ChiTietDichVu c : dp.dichVus) {
                DichVu dv = ds.findDV(c.maDV);
                if (dv == null) continue;
                rows.add(new Object[]{dv.tenDV, dv.donVi, UiUtil.money(dv.donGia),
                        c.soLuong, UiUtil.money(dv.donGia * c.soLuong), UiUtil.date(c.ngay)});
            }
            lbKhach.setText("Đang phục vụ: " + ds.tenKH(dp.maKH) + " - phòng " + dp.maPhong
                    + " - nhận phòng lúc " + UiUtil.dateTime(dp.ngayCheckIn));
        } else {
            lbKhach.setText("(không có phiếu nào đang sử dụng)");
        }
        UiUtil.fill(table, rows);
        lbTong.setText("Tổng tiền dịch vụ: " + (dp == null ? UiUtil.money(0) : UiUtil.money(ds.tienDichVu(dp))));
    }

    private DatPhong selectedPhieuQuiet() {
        Object it = cbPhieu.getSelectedItem();
        if (it == null) return null;
        String ma = it.toString().split(" - ")[0].trim();
        return DataStore.get().datPhongs.stream().filter(d -> d.maDP.equals(ma)).findFirst().orElse(null);
    }
}
