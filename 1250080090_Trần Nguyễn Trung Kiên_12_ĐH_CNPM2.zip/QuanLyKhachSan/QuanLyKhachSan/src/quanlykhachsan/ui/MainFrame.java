package quanlykhachsan.ui;

import quanlykhachsan.util.UiUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {

    public MainFrame() {
        super("Quản lý khách sạn");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1160, 640);
        setMinimumSize(new Dimension(1080, 560));
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(new Color(0xEEEEEE));
        setContentPane(root);

        JLabel title = new JLabel("HỆ THỐNG QUẢN LÝ KHÁCH SẠN", SwingConstants.CENTER);
        title.setFont(new Font("Times New Roman", Font.BOLD, 36));
        title.setForeground(new Color(0x1F3864));

        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(16, 20, 16, 20);

        g.gridx = 0;
        g.gridy = 0;
        g.gridwidth = 3;
        root.add(title, g);
        g.gridwidth = 1;

        JButton first = addButton(root, g, "Danh mục", 0, 1);
        addButton(root, g, "Phòng - Tiện nghi", 1, 1);
        addButton(root, g, "Đặt / Nhận phòng", 2, 1);
        addButton(root, g, "Sử dụng dịch vụ", 0, 2);
        addButton(root, g, "Trả phòng - Thanh toán", 1, 2);
        addButton(root, g, "Thống kê", 2, 2);
        addButton(root, g, "Thoát", 1, 3, e -> {
            if (UiUtil.confirm(this, "Bạn có chắc muốn thoát chương trình?")) System.exit(0);
        });

        SwingUtilities.invokeLater(first::requestFocusInWindow);
    }

    private JButton addButton(JPanel root, GridBagConstraints g, String text, int x, int y) {
        return addButton(root, g, text, x, y, e -> open(text));
    }

    private JButton addButton(JPanel root, GridBagConstraints g, String text, int x, int y, ActionListener action) {
        JButton b = new JButton(text);
        b.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        b.setPreferredSize(new Dimension(310, 76));
        b.addActionListener(action);
        g.gridx = x;
        g.gridy = y;
        root.add(b, g);
        return b;
    }

    private void open(String name) {
        switch (name) {
            case "Danh mục" -> new DanhMucFrame().setVisible(true);
            case "Phòng - Tiện nghi" -> new PhongFrame().setVisible(true);
            case "Đặt / Nhận phòng" -> new DatNhanPhongFrame().setVisible(true);
            case "Sử dụng dịch vụ" -> new SuDungDichVuFrame().setVisible(true);
            case "Trả phòng - Thanh toán" -> new TraPhongFrame().setVisible(true);
            case "Thống kê" -> new ThongKeFrame().setVisible(true);
        }
    }
}
