package quanlykhachsan.ui;

import quanlykhachsan.DataStore;
import quanlykhachsan.model.DatPhong;
import quanlykhachsan.model.KhachHang;
import quanlykhachsan.model.LoaiPhong;
import quanlykhachsan.model.NhanVien;
import quanlykhachsan.model.Phong;
import quanlykhachsan.model.DichVu;
import quanlykhachsan.util.UiUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DanhMucFrame extends JFrame {

    public DanhMucFrame() {
        super("Danh mục");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1120, 660);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        tabs.addTab("  Khách hàng  ", khachHangPanel());
        tabs.addTab("  Nhân viên  ", nhanVienPanel());
        tabs.addTab("  Loại phòng  ", loaiPhongPanel());
        tabs.addTab("  Dịch vụ  ", dichVuPanel());
        setContentPane(tabs);
    }

    // ==================== Hàm dựng layout dùng chung ====================
    private int addRow(JPanel form, GridBagConstraints f, int row, String label, JComponent comp) {
        f.gridx = 0;
        f.gridy = row;
        form.add(new JLabel(label), f);
        f.gridx = 1;
        f.fill = GridBagConstraints.HORIZONTAL;
        form.add(comp, f);
        f.fill = GridBagConstraints.NONE;
        return row + 1;
    }

    private JTable newTable(String[] cols, int... widths) {
        JTable t = new JTable(UiUtil.model(cols));
        t.setRowHeight(26);
        t.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        UiUtil.widths(t, widths);
        return t;
    }

    private void selectById(JTable table, String id) {
        DefaultTableModel m = (DefaultTableModel) table.getModel();
        for (int i = 0; i < m.getRowCount(); i++) {
            if (id.equals(m.getValueAt(i, 0))) {
                table.setRowSelectionInterval(i, i);
                table.scrollRectToVisible(table.getCellRect(i, 0, true));
                return;
            }
        }
    }

    private JPanel searchPanel(String hint, JTextField tfSearch) {
        JPanel north = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        north.add(new JLabel("Tìm kiếm:"));
        north.add(tfSearch);
        JLabel lbHint = new JLabel(hint);
        lbHint.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lbHint.setForeground(Color.GRAY);
        north.add(lbHint);
        return north;
    }

    // ==================== 1. KHÁCH HÀNG ====================
    private JPanel khachHangPanel() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBorder(new EmptyBorder(12, 12, 12, 12));

        JTextField tfMa = new JTextField(16);
        tfMa.setEditable(false);
        JTextField tfTen = new JTextField(16);
        JTextField tfCmnd = new JTextField(16);
        JTextField tfSdt = new JTextField(16);
        JComboBox<String> cbGt = new JComboBox<>(new String[]{"Nam", "Nữ"});
        JTextField tfNs = new JTextField(16);
        JTextField tfDc = new JTextField(16);
        JTextField tfSearch = new JTextField(18);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Thông tin khách hàng"));
        GridBagConstraints f = new GridBagConstraints();
        f.insets = new Insets(4, 6, 4, 6);
        f.anchor = GridBagConstraints.WEST;
        int r = 0;
        r = addRow(form, f, r, "Mã KH (tự sinh):", tfMa);
        r = addRow(form, f, r, "Họ tên (*):", tfTen);
        r = addRow(form, f, r, "CMND/CCCD (*):", tfCmnd);
        r = addRow(form, f, r, "Số điện thoại:", tfSdt);
        r = addRow(form, f, r, "Giới tính:", cbGt);
        r = addRow(form, f, r, "Ngày sinh:", tfNs);
        addRow(form, f, r, "Địa chỉ:", tfDc);

        JTable table = newTable(new String[]{"Mã KH", "Họ tên", "CMND/CCCD", "Số điện thoại", "Giới tính", "Ngày sinh", "Địa chỉ"},
                70, 180, 130, 120, 80, 95, 230);

        Runnable refresh = () -> {
            String kw = tfSearch.getText().trim().toLowerCase();
            List<Object[]> rows = new ArrayList<>();
            for (KhachHang k : DataStore.get().khachHangs) {
                if (!kw.isEmpty()
                        && !(k.hoTen.toLowerCase().contains(kw) || k.cmnd.toLowerCase().contains(kw)
                        || k.sdt.contains(kw) || k.maKH.toLowerCase().contains(kw)))
                    continue;
                rows.add(new Object[]{k.maKH, k.hoTen, k.cmnd, k.sdt, k.gioiTinh, UiUtil.date(k.ngaySinh), k.diaChi});
            }
            UiUtil.fill(table, rows);
        };
        Runnable clear = () -> {
            tfMa.setText("");
            tfTen.setText("");
            tfCmnd.setText("");
            tfSdt.setText("");
            tfNs.setText("");
            tfDc.setText("");
            cbGt.setSelectedIndex(0);
            table.clearSelection();
        };
        refresh.run();
        UiUtil.onChanged(tfSearch, refresh);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting() || table.getSelectedRow() < 0) return;
            KhachHang k = DataStore.get().findKH((String) table.getModel().getValueAt(table.getSelectedRow(), 0));
            if (k == null) return;
            tfMa.setText(k.maKH);
            tfTen.setText(k.hoTen);
            tfCmnd.setText(k.cmnd);
            tfSdt.setText(k.sdt);
            cbGt.setSelectedItem(k.gioiTinh);
            tfNs.setText(UiUtil.date(k.ngaySinh));
            tfDc.setText(k.diaChi);
        });

        JButton btnAdd = UiUtil.btn("Thêm");
        btnAdd.addActionListener(e -> {
            try {
                String ten = tfTen.getText().trim(), cmnd = tfCmnd.getText().trim();
                if (ten.isEmpty() || cmnd.isEmpty()) {
                    UiUtil.err(this, "Vui lòng nhập họ tên và CMND/CCCD.");
                    return;
                }
                LocalDate ns = tfNs.getText().trim().isEmpty() ? null : UiUtil.parseDate(tfNs.getText());
                if (ns != null && ns.isAfter(LocalDate.now())) {
                    UiUtil.err(this, "Ngày sinh không thể ở tương lai.");
                    return;
                }
                for (KhachHang k : DataStore.get().khachHangs)
                    if (k.cmnd.equals(cmnd)) {
                        UiUtil.err(this, "CMND/CCCD này đã tồn tại trong danh mục.");
                        return;
                    }
                KhachHang k = new KhachHang(DataStore.get().nextMaKH(), ten, cmnd, tfSdt.getText().trim(),
                        (String) cbGt.getSelectedItem(), ns, tfDc.getText().trim());
                DataStore.get().khachHangs.add(k);
                DataStore.get().save();
                tfSearch.setText("");
                refresh.run();
                selectById(table, k.maKH);
                UiUtil.msg(this, "Đã thêm khách hàng: " + k.maKH + " - " + k.hoTen);
            } catch (Exception ex) {
                UiUtil.err(this, ex.getMessage());
            }
        });

        JButton btnUpdate = UiUtil.btn("Cập nhật");
        btnUpdate.addActionListener(e -> {
            KhachHang k = DataStore.get().findKH(tfMa.getText().trim());
            if (k == null) {
                UiUtil.err(this, "Hãy chọn khách hàng cần cập nhật trong bảng.");
                return;
            }
            try {
                if (tfTen.getText().trim().isEmpty() || tfCmnd.getText().trim().isEmpty()) {
                    UiUtil.err(this, "Vui lòng nhập họ tên và CMND/CCCD.");
                    return;
                }
                LocalDate ns = tfNs.getText().trim().isEmpty() ? null : UiUtil.parseDate(tfNs.getText());
                for (KhachHang o : DataStore.get().khachHangs)
                    if (o != k && o.cmnd.equals(tfCmnd.getText().trim())) {
                        UiUtil.err(this, "CMND/CCCD đã tồn tại ở khách hàng khác.");
                        return;
                    }
                k.hoTen = tfTen.getText().trim();
                k.cmnd = tfCmnd.getText().trim();
                k.sdt = tfSdt.getText().trim();
                k.gioiTinh = (String) cbGt.getSelectedItem();
                k.ngaySinh = ns;
                k.diaChi = tfDc.getText().trim();
                DataStore.get().save();
                refresh.run();
                selectById(table, k.maKH);
                UiUtil.msg(this, "Đã cập nhật khách hàng " + k.maKH);
            } catch (Exception ex) {
                UiUtil.err(this, ex.getMessage());
            }
        });

        JButton btnDelete = UiUtil.btn("Xóa");
        btnDelete.addActionListener(e -> {
            KhachHang k = DataStore.get().findKH(tfMa.getText().trim());
            if (k == null) {
                UiUtil.err(this, "Hãy chọn khách hàng cần xóa trong bảng.");
                return;
            }
            for (DatPhong dp : DataStore.get().datPhongs)
                if (dp.maKH.equals(k.maKH) && (dp.trangThai.equals(DatPhong.DAT_TRUOC) || dp.trangThai.equals(DatPhong.DANG_SU_DUNG))) {
                    UiUtil.err(this, "Không thể xóa: khách hàng đang có phiếu " + dp.maDP + " chưa trả phòng.");
                    return;
                }
            if (!UiUtil.confirm(this, "Xóa khách hàng " + k.maKH + " - " + k.hoTen + "?")) return;
            DataStore.get().khachHangs.remove(k);
            DataStore.get().save();
            refresh.run();
            clear.run();
        });

        JButton btnClear = UiUtil.btn("Làm mới");
        btnClear.addActionListener(e -> clear.run());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.add(btnAdd);
        buttons.add(btnUpdate);
        buttons.add(btnDelete);
        buttons.add(btnClear);

        p.add(searchPanel("(theo tên, CMND, SĐT, mã KH)", tfSearch), BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        p.add(buttons, BorderLayout.SOUTH);
        p.add(form, BorderLayout.EAST);
        return p;
    }

    // ==================== 2. NHÂN VIÊN ====================
    private JPanel nhanVienPanel() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBorder(new EmptyBorder(12, 12, 12, 12));

        JTextField tfMa = new JTextField(16);
        tfMa.setEditable(false);
        JTextField tfTen = new JTextField(16);
        JComboBox<String> cbGt = new JComboBox<>(new String[]{"Nam", "Nữ"});
        JTextField tfSdt = new JTextField(16);
        JComboBox<String> cbChucVu = new JComboBox<>(new String[]{"Quản lý", "Lễ tân", "Buồng phòng", "Kỹ thuật"});
        JTextField tfSearch = new JTextField(18);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Thông tin nhân viên"));
        GridBagConstraints f = new GridBagConstraints();
        f.insets = new Insets(4, 6, 4, 6);
        f.anchor = GridBagConstraints.WEST;
        int r = 0;
        r = addRow(form, f, r, "Mã NV (tự sinh):", tfMa);
        r = addRow(form, f, r, "Họ tên (*):", tfTen);
        r = addRow(form, f, r, "Giới tính:", cbGt);
        r = addRow(form, f, r, "Số điện thoại:", tfSdt);
        addRow(form, f, r, "Chức vụ:", cbChucVu);

        JTable table = newTable(new String[]{"Mã NV", "Họ tên", "Giới tính", "Số điện thoại", "Chức vụ"},
                90, 220, 100, 150, 150);

        Runnable refresh = () -> {
            String kw = tfSearch.getText().trim().toLowerCase();
            List<Object[]> rows = new ArrayList<>();
            for (NhanVien k : DataStore.get().nhanViens) {
                if (!kw.isEmpty()
                        && !(k.hoTen.toLowerCase().contains(kw) || k.maNV.toLowerCase().contains(kw)
                        || k.chucVu.toLowerCase().contains(kw) || k.sdt.contains(kw)))
                    continue;
                rows.add(new Object[]{k.maNV, k.hoTen, k.gioiTinh, k.sdt, k.chucVu});
            }
            UiUtil.fill(table, rows);
        };
        Runnable clear = () -> {
            tfMa.setText("");
            tfTen.setText("");
            tfSdt.setText("");
            cbGt.setSelectedIndex(0);
            cbChucVu.setSelectedIndex(0);
            table.clearSelection();
        };
        refresh.run();
        UiUtil.onChanged(tfSearch, refresh);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting() || table.getSelectedRow() < 0) return;
            NhanVien k = DataStore.get().nhanViens.stream()
                    .filter(x -> x.maNV.equals(table.getModel().getValueAt(table.getSelectedRow(), 0)))
                    .findFirst().orElse(null);
            if (k == null) return;
            tfMa.setText(k.maNV);
            tfTen.setText(k.hoTen);
            cbGt.setSelectedItem(k.gioiTinh);
            tfSdt.setText(k.sdt);
            cbChucVu.setSelectedItem(k.chucVu);
        });

        JButton btnAdd = UiUtil.btn("Thêm");
        btnAdd.addActionListener(e -> {
            if (tfTen.getText().trim().isEmpty()) {
                UiUtil.err(this, "Vui lòng nhập họ tên nhân viên.");
                return;
            }
            NhanVien k = new NhanVien(DataStore.get().nextMaNV(), tfTen.getText().trim(),
                    (String) cbGt.getSelectedItem(), tfSdt.getText().trim(), (String) cbChucVu.getSelectedItem());
            DataStore.get().nhanViens.add(k);
            DataStore.get().save();
            tfSearch.setText("");
            refresh.run();
            selectById(table, k.maNV);
            UiUtil.msg(this, "Đã thêm nhân viên: " + k.maNV + " - " + k.hoTen);
        });

        JButton btnUpdate = UiUtil.btn("Cập nhật");
        btnUpdate.addActionListener(e -> {
            NhanVien k = DataStore.get().findNV(tfMa.getText().trim());
            if (k == null) {
                UiUtil.err(this, "Hãy chọn nhân viên cần cập nhật trong bảng.");
                return;
            }
            if (tfTen.getText().trim().isEmpty()) {
                UiUtil.err(this, "Vui lòng nhập họ tên nhân viên.");
                return;
            }
            k.hoTen = tfTen.getText().trim();
            k.gioiTinh = (String) cbGt.getSelectedItem();
            k.sdt = tfSdt.getText().trim();
            k.chucVu = (String) cbChucVu.getSelectedItem();
            DataStore.get().save();
            refresh.run();
            selectById(table, k.maNV);
            UiUtil.msg(this, "Đã cập nhật nhân viên " + k.maNV);
        });

        JButton btnDelete = UiUtil.btn("Xóa");
        btnDelete.addActionListener(e -> {
            NhanVien k = DataStore.get().findNV(tfMa.getText().trim());
            if (k == null) {
                UiUtil.err(this, "Hãy chọn nhân viên cần xóa trong bảng.");
                return;
            }
            if (!UiUtil.confirm(this, "Xóa nhân viên " + k.maNV + " - " + k.hoTen + "?")) return;
            DataStore.get().nhanViens.remove(k);
            DataStore.get().save();
            refresh.run();
            clear.run();
        });

        JButton btnClear = UiUtil.btn("Làm mới");
        btnClear.addActionListener(e -> clear.run());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.add(btnAdd);
        buttons.add(btnUpdate);
        buttons.add(btnDelete);
        buttons.add(btnClear);

        p.add(searchPanel("(theo tên, chức vụ, SĐT, mã NV)", tfSearch), BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        p.add(buttons, BorderLayout.SOUTH);
        p.add(form, BorderLayout.EAST);
        return p;
    }

    // ==================== 3. LOẠI PHÒNG ====================
    private JPanel loaiPhongPanel() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBorder(new EmptyBorder(12, 12, 12, 12));

        JTextField tfMa = new JTextField(16);
        tfMa.setEditable(false);
        JTextField tfTen = new JTextField(16);
        JTextField tfGia = new JTextField(16);
        JTextField tfTienIch = new JTextField(16);
        JTextField tfSearch = new JTextField(18);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Thông tin loại phòng"));
        GridBagConstraints f = new GridBagConstraints();
        f.insets = new Insets(4, 6, 4, 6);
        f.anchor = GridBagConstraints.WEST;
        int r = 0;
        r = addRow(form, f, r, "Mã loại (tự sinh):", tfMa);
        r = addRow(form, f, r, "Tên loại (*):", tfTen);
        r = addRow(form, f, r, "Đơn giá/đêm (*):", tfGia);
        r = addRow(form, f, r, "Tiện nghi:", tfTienIch);
        JLabel lbHint = new JLabel("<html>(tiện nghi cách nhau<br>bởi dấu phẩy ,)</html>");
        lbHint.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lbHint.setForeground(Color.GRAY);
        f.gridx = 1;
        f.gridy = r;
        form.add(lbHint, f);

        JTable table = newTable(new String[]{"Mã loại", "Tên loại", "Đơn giá/đêm", "Tiện nghi"},
                90, 150, 140, 400);

        Runnable refresh = () -> {
            String kw = tfSearch.getText().trim().toLowerCase();
            List<Object[]> rows = new ArrayList<>();
            for (LoaiPhong k : DataStore.get().loaiPhongs) {
                if (!kw.isEmpty()
                        && !(k.tenLoai.toLowerCase().contains(kw) || k.maLoai.toLowerCase().contains(kw)
                        || k.tienIchText().toLowerCase().contains(kw)))
                    continue;
                rows.add(new Object[]{k.maLoai, k.tenLoai, UiUtil.money(k.donGia), k.tienIchText()});
            }
            UiUtil.fill(table, rows);
        };
        Runnable clear = () -> {
            tfMa.setText("");
            tfTen.setText("");
            tfGia.setText("");
            tfTienIch.setText("");
            table.clearSelection();
        };
        refresh.run();
        UiUtil.onChanged(tfSearch, refresh);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting() || table.getSelectedRow() < 0) return;
            LoaiPhong k = DataStore.get().findLoai((String) table.getModel().getValueAt(table.getSelectedRow(), 0));
            if (k == null) return;
            tfMa.setText(k.maLoai);
            tfTen.setText(k.tenLoai);
            tfGia.setText(String.valueOf((long) k.donGia));
            tfTienIch.setText(k.tienIchText());
        });

        JButton btnAdd = UiUtil.btn("Thêm");
        btnAdd.addActionListener(e -> {
            try {
                String ten = tfTen.getText().trim();
                if (ten.isEmpty()) {
                    UiUtil.err(this, "Vui lòng nhập tên loại phòng.");
                    return;
                }
                double gia = UiUtil.parseMoney(tfGia.getText(), "Đơn giá");
                if (gia <= 0) {
                    UiUtil.err(this, "Đơn giá phải lớn hơn 0.");
                    return;
                }
                LoaiPhong k = new LoaiPhong(DataStore.get().nextMaLoai(), ten, gia);
                for (String t : tfTienIch.getText().split(","))
                    if (!t.trim().isEmpty()) k.tienIch.add(t.trim());
                DataStore.get().loaiPhongs.add(k);
                DataStore.get().save();
                tfSearch.setText("");
                refresh.run();
                selectById(table, k.maLoai);
                UiUtil.msg(this, "Đã thêm loại phòng: " + k.maLoai + " - " + k.tenLoai);
            } catch (Exception ex) {
                UiUtil.err(this, ex.getMessage());
            }
        });

        JButton btnUpdate = UiUtil.btn("Cập nhật");
        btnUpdate.addActionListener(e -> {
            LoaiPhong k = DataStore.get().findLoai(tfMa.getText().trim());
            if (k == null) {
                UiUtil.err(this, "Hãy chọn loại phòng cần cập nhật trong bảng.");
                return;
            }
            try {
                if (tfTen.getText().trim().isEmpty()) {
                    UiUtil.err(this, "Vui lòng nhập tên loại phòng.");
                    return;
                }
                double gia = UiUtil.parseMoney(tfGia.getText(), "Đơn giá");
                if (gia <= 0) {
                    UiUtil.err(this, "Đơn giá phải lớn hơn 0.");
                    return;
                }
                k.tenLoai = tfTen.getText().trim();
                k.donGia = gia;
                k.tienIch.clear();
                for (String t : tfTienIch.getText().split(","))
                    if (!t.trim().isEmpty()) k.tienIch.add(t.trim());
                DataStore.get().save();
                refresh.run();
                selectById(table, k.maLoai);
                UiUtil.msg(this, "Đã cập nhật loại phòng " + k.maLoai);
            } catch (Exception ex) {
                UiUtil.err(this, ex.getMessage());
            }
        });

        JButton btnDelete = UiUtil.btn("Xóa");
        btnDelete.addActionListener(e -> {
            LoaiPhong k = DataStore.get().findLoai(tfMa.getText().trim());
            if (k == null) {
                UiUtil.err(this, "Hãy chọn loại phòng cần xóa trong bảng.");
                return;
            }
            long dangDung = DataStore.get().phongs.stream().filter(x -> x.maLoai.equals(k.maLoai)).count();
            if (dangDung > 0) {
                UiUtil.err(this, "Không thể xóa: còn " + dangDung + " phòng thuộc loại này. Hãy xóa/hẹn các phòng trước.");
                return;
            }
            if (!UiUtil.confirm(this, "Xóa loại phòng " + k.maLoai + " - " + k.tenLoai + "?")) return;
            DataStore.get().loaiPhongs.remove(k);
            DataStore.get().save();
            refresh.run();
            clear.run();
        });

        JButton btnClear = UiUtil.btn("Làm mới");
        btnClear.addActionListener(e -> clear.run());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.add(btnAdd);
        buttons.add(btnUpdate);
        buttons.add(btnDelete);
        buttons.add(btnClear);

        p.add(searchPanel("(theo tên loại, tiện nghi, mã)", tfSearch), BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        p.add(buttons, BorderLayout.SOUTH);
        p.add(form, BorderLayout.EAST);
        return p;
    }

    // ==================== 4. DỊCH VỤ ====================
    private JPanel dichVuPanel() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBorder(new EmptyBorder(12, 12, 12, 12));

        JTextField tfMa = new JTextField(16);
        tfMa.setEditable(false);
        JTextField tfTen = new JTextField(16);
        JTextField tfGia = new JTextField(16);
        JTextField tfDonVi = new JTextField(16);
        JTextField tfSearch = new JTextField(18);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Thông tin dịch vụ"));
        GridBagConstraints f = new GridBagConstraints();
        f.insets = new Insets(4, 6, 4, 6);
        f.anchor = GridBagConstraints.WEST;
        int r = 0;
        r = addRow(form, f, r, "Mã DV (tự sinh):", tfMa);
        r = addRow(form, f, r, "Tên dịch vụ (*):", tfTen);
        r = addRow(form, f, r, "Đơn giá (*):", tfGia);
        addRow(form, f, r, "Đơn vị tính:", tfDonVi);

        JTable table = newTable(new String[]{"Mã DV", "Tên dịch vụ", "Đơn giá", "Đơn vị"},
                90, 260, 140, 100);

        Runnable refresh = () -> {
            String kw = tfSearch.getText().trim().toLowerCase();
            List<Object[]> rows = new ArrayList<>();
            for (DichVu k : DataStore.get().dichVus) {
                if (!kw.isEmpty()
                        && !(k.tenDV.toLowerCase().contains(kw) || k.maDV.toLowerCase().contains(kw)))
                    continue;
                rows.add(new Object[]{k.maDV, k.tenDV, UiUtil.money(k.donGia), k.donVi});
            }
            UiUtil.fill(table, rows);
        };
        Runnable clear = () -> {
            tfMa.setText("");
            tfTen.setText("");
            tfGia.setText("");
            tfDonVi.setText("");
            table.clearSelection();
        };
        refresh.run();
        UiUtil.onChanged(tfSearch, refresh);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting() || table.getSelectedRow() < 0) return;
            DichVu k = DataStore.get().findDV((String) table.getModel().getValueAt(table.getSelectedRow(), 0));
            if (k == null) return;
            tfMa.setText(k.maDV);
            tfTen.setText(k.tenDV);
            tfGia.setText(String.valueOf((long) k.donGia));
            tfDonVi.setText(k.donVi);
        });

        JButton btnAdd = UiUtil.btn("Thêm");
        btnAdd.addActionListener(e -> {
            try {
                String ten = tfTen.getText().trim();
                if (ten.isEmpty()) {
                    UiUtil.err(this, "Vui lòng nhập tên dịch vụ.");
                    return;
                }
                double gia = UiUtil.parseMoney(tfGia.getText(), "Đơn giá");
                if (gia <= 0) {
                    UiUtil.err(this, "Đơn giá phải lớn hơn 0.");
                    return;
                }
                DichVu k = new DichVu(DataStore.get().nextMaDV(), ten, gia,
                        tfDonVi.getText().trim().isEmpty() ? "lượt" : tfDonVi.getText().trim());
                DataStore.get().dichVus.add(k);
                DataStore.get().save();
                tfSearch.setText("");
                refresh.run();
                selectById(table, k.maDV);
                UiUtil.msg(this, "Đã thêm dịch vụ: " + k.maDV + " - " + k.tenDV);
            } catch (Exception ex) {
                UiUtil.err(this, ex.getMessage());
            }
        });

        JButton btnUpdate = UiUtil.btn("Cập nhật");
        btnUpdate.addActionListener(e -> {
            DichVu k = DataStore.get().findDV(tfMa.getText().trim());
            if (k == null) {
                UiUtil.err(this, "Hãy chọn dịch vụ cần cập nhật trong bảng.");
                return;
            }
            try {
                if (tfTen.getText().trim().isEmpty()) {
                    UiUtil.err(this, "Vui lòng nhập tên dịch vụ.");
                    return;
                }
                k.tenDV = tfTen.getText().trim();
                k.donGia = UiUtil.parseMoney(tfGia.getText(), "Đơn giá");
                k.donVi = tfDonVi.getText().trim().isEmpty() ? "lượt" : tfDonVi.getText().trim();
                DataStore.get().save();
                refresh.run();
                selectById(table, k.maDV);
                UiUtil.msg(this, "Đã cập nhật dịch vụ " + k.maDV);
            } catch (Exception ex) {
                UiUtil.err(this, ex.getMessage());
            }
        });

        JButton btnDelete = UiUtil.btn("Xóa");
        btnDelete.addActionListener(e -> {
            DichVu k = DataStore.get().findDV(tfMa.getText().trim());
            if (k == null) {
                UiUtil.err(this, "Hãy chọn dịch vụ cần xóa trong bảng.");
                return;
            }
            boolean dangDung = DataStore.get().datPhongs.stream()
                    .anyMatch(dp -> dp.dichVus.stream().anyMatch(c -> c.maDV.equals(k.maDV)));
            if (dangDung) {
                UiUtil.err(this, "Không thể xóa: dịch vụ đã được khách sử dụng trong các phiếu thuê.");
                return;
            }
            if (!UiUtil.confirm(this, "Xóa dịch vụ " + k.maDV + " - " + k.tenDV + "?")) return;
            DataStore.get().dichVus.remove(k);
            DataStore.get().save();
            refresh.run();
            clear.run();
        });

        JButton btnClear = UiUtil.btn("Làm mới");
        btnClear.addActionListener(e -> clear.run());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.add(btnAdd);
        buttons.add(btnUpdate);
        buttons.add(btnDelete);
        buttons.add(btnClear);

        p.add(searchPanel("(theo tên dịch vụ, mã)", tfSearch), BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        p.add(buttons, BorderLayout.SOUTH);
        p.add(form, BorderLayout.EAST);
        return p;
    }
}
