package quanlykhachsan.ui;

import quanlykhachsan.DataStore;
import quanlykhachsan.model.LoaiPhong;
import quanlykhachsan.model.Phong;
import quanlykhachsan.util.UiUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class PhongFrame extends JFrame {

    public PhongFrame() {
        super("Phòng - Tiện nghi");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1150, 640);
        setLocationRelativeTo(null);

        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBorder(new EmptyBorder(12, 12, 12, 12));

        JTextField tfMa = new JTextField(16);
        JComboBox<String> cbLoai = new JComboBox<>();
        JSpinner spTang = new JSpinner(new SpinnerNumberModel(1, 1, 50, 1));
        JComboBox<String> cbTrangThai = new JComboBox<>(new String[]{Phong.TRONG, Phong.DA_DAT, Phong.CO_KHACH, Phong.BAO_TRI});
        JLabel lbTienIch = new JLabel(" ");
        lbTienIch.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lbTienIch.setForeground(new Color(0x1F3864));
        JComboBox<String> cbFilter = new JComboBox<>(new String[]{"Tất cả", Phong.TRONG, Phong.DA_DAT, Phong.CO_KHACH, Phong.BAO_TRI});
        JTextField tfSearch = new JTextField(18);
        JLabel lbTongQuat = new JLabel(" ");
        lbTongQuat.setFont(new Font("Segoe UI", Font.BOLD, 13));

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Thông tin phòng"));
        GridBagConstraints f = new GridBagConstraints();
        f.insets = new Insets(4, 6, 4, 6);
        f.anchor = GridBagConstraints.WEST;
        int r = 0;
        r = addRow(form, f, r, "Mã phòng (*):", tfMa);
        r = addRow(form, f, r, "Loại phòng:", cbLoai);
        r = addRow(form, f, r, "Tầng:", spTang);
        r = addRow(form, f, r, "Trạng thái:", cbTrangThai);
        f.gridx = 0;
        f.gridy = r;
        f.gridwidth = 2;
        form.add(new JLabel("Tiện nghi loại đã chọn:"), f);
        f.gridy = r + 1;
        form.add(lbTienIch, f);
        f.gridwidth = 1;

        JTable table = new JTable(UiUtil.model(new String[]{"Mã phòng", "Loại phòng", "Đơn giá/đêm", "Tầng", "Tiện nghi", "Trạng thái"}));
        table.setRowHeight(26);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        UiUtil.widths(table, 90, 120, 130, 60, 320, 100);

        Runnable loadCombos = () -> {
            Object sel = cbLoai.getSelectedItem();
            cbLoai.removeAllItems();
            for (LoaiPhong lp : DataStore.get().loaiPhongs)
                cbLoai.addItem(lp.maLoai + " - " + lp.tenLoai);
            if (sel != null) cbLoai.setSelectedItem(sel);
        };
        loadCombos.run();

        Runnable showTienIch = () -> {
            LoaiPhong lp = findSelectedLoai(cbLoai);
            lbTienIch.setText(lp == null ? " " : lp.tienIchText());
        };
        showTienIch.run();

        Runnable refresh = () -> {
            String filter = (String) cbFilter.getSelectedItem();
            String kw = tfSearch.getText().trim().toLowerCase();
            DataStore ds = DataStore.get();
            List<Object[]> rows = new ArrayList<>();
            for (Phong k : ds.phongs) {
                if (!filter.equals("Tất cả") && !k.trangThai.equals(filter)) continue;
                LoaiPhong lp = ds.findLoai(k.maLoai);
                String loai = lp == null ? k.maLoai : lp.tenLoai;
                String gia = lp == null ? "" : UiUtil.money(lp.donGia);
                String tienIch = lp == null ? "" : lp.tienIchText();
                if (!kw.isEmpty() && !(k.maPhong.toLowerCase().contains(kw) || loai.toLowerCase().contains(kw)))
                    continue;
                rows.add(new Object[]{k.maPhong, loai, gia, k.tang, tienIch, k.trangThai});
            }
            UiUtil.fill(table, rows);

            long trong = ds.phongs.stream().filter(x -> x.trangThai.equals(Phong.TRONG)).count();
            long dadat = ds.phongs.stream().filter(x -> x.trangThai.equals(Phong.DA_DAT)).count();
            long cokhach = ds.phongs.stream().filter(x -> x.trangThai.equals(Phong.CO_KHACH)).count();
            long baotri = ds.phongs.stream().filter(x -> x.trangThai.equals(Phong.BAO_TRI)).count();
            lbTongQuat.setText("Tổng: " + ds.phongs.size() + " phòng  |  Trống: " + trong
                    + "  |  Đã đặt: " + dadat + "  |  Có khách: " + cokhach + "  |  Bảo trì: " + baotri);
        };
        refresh.run();
        UiUtil.onChanged(tfSearch, refresh);
        cbFilter.addActionListener(e -> refresh.run());
        cbLoai.addActionListener(e -> showTienIch.run());

        String[] selectedMa = {null};
        table.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting() || table.getSelectedRow() < 0) return;
            String ma = (String) table.getModel().getValueAt(table.getSelectedRow(), 0);
            Phong k = DataStore.get().findPhong(ma);
            if (k == null) return;
            selectedMa[0] = k.maPhong;
            tfMa.setText(k.maPhong);
            LoaiPhong lp = DataStore.get().findLoai(k.maLoai);
            if (lp != null) cbLoai.setSelectedItem(lp.maLoai + " - " + lp.tenLoai);
            spTang.setValue(k.tang);
            cbTrangThai.setSelectedItem(k.trangThai);
        });

        JButton btnAdd = UiUtil.btn("Thêm");
        btnAdd.addActionListener(e -> {
            DataStore ds = DataStore.get();
            String ma = tfMa.getText().trim().toUpperCase();
            if (ma.isEmpty()) {
                UiUtil.err(this, "Vui lòng nhập mã phòng (ví dụ P105).");
                return;
            }
            if (ds.findPhong(ma) != null) {
                UiUtil.err(this, "Mã phòng \"" + ma + "\" đã tồn tại.");
                return;
            }
            LoaiPhong lp = findSelectedLoai(cbLoai);
            if (lp == null) {
                UiUtil.err(this, "Vui lòng chọn loại phòng.");
                return;
            }
            if (!cbTrangThai.getSelectedItem().equals(Phong.TRONG)) {
                UiUtil.err(this, "Phòng mới thêm phải ở trạng thái \"Trống\".");
                return;
            }
            Phong k = new Phong(ma, lp.maLoai, (Integer) spTang.getValue(), Phong.TRONG);
            ds.phongs.add(k);
            ds.save();
            tfSearch.setText("");
            refresh.run();
            UiUtil.msg(this, "Đã thêm phòng " + k.maPhong + " (" + lp.tenLoai + ", tầng " + k.tang + ").");
        });

        JButton btnUpdate = UiUtil.btn("Cập nhật");
        btnUpdate.addActionListener(e -> {
            DataStore ds = DataStore.get();
            Phong k = selectedMa[0] == null ? null : ds.findPhong(selectedMa[0]);
            if (k == null) {
                UiUtil.err(this, "Hãy chọn phòng cần cập nhật trong bảng.");
                return;
            }
            LoaiPhong lp = findSelectedLoai(cbLoai);
            if (lp == null) {
                UiUtil.err(this, "Vui lòng chọn loại phòng.");
                return;
            }
            String trangThaiMoi = (String) cbTrangThai.getSelectedItem();
            if (!k.trangThai.equals(trangThaiMoi) && !k.trangThai.equals(Phong.TRONG) && !trangThaiMoi.equals(Phong.TRONG)) {
                if (!UiUtil.confirm(this, "Phòng đang \"" + k.trangThai + "\". Đổi sang \"" + trangThaiMoi + "\"?"))
                    return;
            }
            k.maLoai = lp.maLoai;
            k.tang = (Integer) spTang.getValue();
            k.trangThai = trangThaiMoi;
            ds.save();
            refresh.run();
            UiUtil.msg(this, "Đã cập nhật phòng " + k.maPhong);
        });

        JButton btnDelete = UiUtil.btn("Xóa");
        btnDelete.addActionListener(e -> {
            DataStore ds = DataStore.get();
            Phong k = selectedMa[0] == null ? null : ds.findPhong(selectedMa[0]);
            if (k == null) {
                UiUtil.err(this, "Hãy chọn phòng cần xóa trong bảng.");
                return;
            }
            if (!k.trangThai.equals(Phong.TRONG)) {
                UiUtil.err(this, "Không thể xóa: phòng đang ở trạng thái \"" + k.trangThai + "\".");
                return;
            }
            if (!UiUtil.confirm(this, "Xóa phòng " + k.maPhong + "?")) return;
            ds.phongs.remove(k);
            ds.save();
            selectedMa[0] = null;
            refresh.run();
        });

        JButton btnClear = UiUtil.btn("Làm mới");
        btnClear.addActionListener(e -> {
            selectedMa[0] = null;
            tfMa.setText("");
            cbTrangThai.setSelectedItem(Phong.TRONG);
            table.clearSelection();
        });

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        top.add(new JLabel("Lọc trạng thái:"));
        top.add(cbFilter);
        top.add(new JLabel("Tìm kiếm:"));
        top.add(tfSearch);
        top.add(lbTongQuat);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.add(btnAdd);
        buttons.add(btnUpdate);
        buttons.add(btnDelete);
        buttons.add(btnClear);

        p.add(top, BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        p.add(buttons, BorderLayout.SOUTH);
        p.add(form, BorderLayout.EAST);
        setContentPane(p);
    }

    private LoaiPhong findSelectedLoai(JComboBox<String> cbLoai) {
        Object it = cbLoai.getSelectedItem();
        if (it == null) return null;
        String ma = it.toString().split(" - ")[0].trim();
        return DataStore.get().findLoai(ma);
    }

    private int addRow(JPanel form, GridBagConstraints f, int row, String label, JComponent comp) {
        f.gridx = 0;
        f.gridy = row;
        form.add(new JLabel(label), f);
        f.gridx = 1;
        f.fill = GridBagConstraints.HORIZONTAL;
        form.add(comp, f);
        f.fill = GridBagConstraints.NONE;
        return row + 1;
    }
}
