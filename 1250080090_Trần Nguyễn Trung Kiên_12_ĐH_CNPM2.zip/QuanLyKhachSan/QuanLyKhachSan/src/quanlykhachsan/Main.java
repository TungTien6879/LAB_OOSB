package quanlykhachsan;

import quanlykhachsan.ui.MainFrame;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }
        DataStore.get(); // nạp dữ liệu (hoặc sinh dữ liệu mẫu lần đầu chạy)
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
