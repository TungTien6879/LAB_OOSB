package quanlykhachsan.model;

import java.io.Serializable;

public class Phong implements Serializable {
    public static final String TRONG = "Trống";
    public static final String DA_DAT = "Đã đặt";
    public static final String CO_KHACH = "Có khách";
    public static final String BAO_TRI = "Bảo trì";

    public String maPhong, maLoai, trangThai;
    public int tang;

    public Phong() {
    }

    public Phong(String maPhong, String maLoai, int tang, String trangThai) {
        this.maPhong = maPhong;
        this.maLoai = maLoai;
        this.tang = tang;
        this.trangThai = trangThai;
    }

    @Override
    public String toString() {
        return maPhong;
    }
}
