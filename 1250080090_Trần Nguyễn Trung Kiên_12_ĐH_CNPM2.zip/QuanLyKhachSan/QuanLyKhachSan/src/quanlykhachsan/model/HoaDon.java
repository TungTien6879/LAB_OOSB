package quanlykhachsan.model;

import java.io.Serializable;
import java.time.LocalDateTime;

public class HoaDon implements Serializable {
    public String maHD, maDP, maKH, tenKH, maPhong, tenLoai, phuongThuc;
    public LocalDateTime ngayCheckIn, ngayCheckOut, ngayLap;
    public long soNgay;
    public double tienPhong, tienDichVu, giamGia, tongTien;
}
