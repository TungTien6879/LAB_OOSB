package quanlykhachsan.model;

import java.io.Serializable;

public class DichVu implements Serializable {
    public String maDV, tenDV, donVi;
    public double donGia;

    public DichVu() {
    }

    public DichVu(String maDV, String tenDV, double donGia, String donVi) {
        this.maDV = maDV;
        this.tenDV = tenDV;
        this.donGia = donGia;
        this.donVi = donVi;
    }
}
