package quanlykhachsan.model;

import java.io.Serializable;
import java.time.LocalDate;

public class ChiTietDichVu implements Serializable {
    public String maDV;
    public int soLuong;
    public LocalDate ngay;

    public ChiTietDichVu() {
    }

    public ChiTietDichVu(String maDV, int soLuong, LocalDate ngay) {
        this.maDV = maDV;
        this.soLuong = soLuong;
        this.ngay = ngay;
    }
}
