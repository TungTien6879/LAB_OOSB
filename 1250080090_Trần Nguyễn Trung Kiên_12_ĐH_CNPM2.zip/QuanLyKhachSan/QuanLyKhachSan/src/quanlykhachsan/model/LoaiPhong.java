package quanlykhachsan.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class LoaiPhong implements Serializable {
    public String maLoai, tenLoai;
    public double donGia;
    public List<String> tienIch = new ArrayList<>();

    public LoaiPhong() {
    }

    public LoaiPhong(String maLoai, String tenLoai, double donGia, String... tienIch) {
        this.maLoai = maLoai;
        this.tenLoai = tenLoai;
        this.donGia = donGia;
        for (String t : tienIch) this.tienIch.add(t);
    }

    public String tienIchText() {
        return String.join(", ", tienIch);
    }
}
